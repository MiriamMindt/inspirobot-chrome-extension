"use strict";

window.browser = require("../../");
